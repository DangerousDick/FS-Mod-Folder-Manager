# fs22-mod-manager
Farming Simulator 22 Mods Folder Manager.
Creates, deletes and managers folders for game/map specific mods to avoid confilcts and simplify loading the mods required by multiplayer servers.

NOTE: This application will change the Farming Simulator 2022 file gameSettings.xml to override the default mod folder location.

Written using python3 and QT5.

Aimed at windows but may work under linux. This HAS NOT BEEN TESTED and may cause issues.

Aimed at FS22 but may work for FS19 if you change some of the settings in the applications config.ini file. This HAS NOT BEEN TESTED and may cause issues.
